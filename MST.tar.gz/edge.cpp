//edge class function implementation
// author Anirudh Yadav

#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <list>
#include <bits/stdc++.h>
#include "vertex.h"
#include "edge.h"

using namespace std;

edge::edge(vertex a, vertex b):v1(a),v2(b),cost(0){}