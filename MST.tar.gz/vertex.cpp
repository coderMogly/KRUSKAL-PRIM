//vertex class function implementation
// author Anirudh Yadav

#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <list>
#include <bits/stdc++.h>
#include "vertex.h"

using namespace std;

vertex::vertex(int a, int cost):ver(a),cost(cost){}





